angular.module('zpzMdCalendarDemo')
.config([
	'zpzMdCalendarSvcProvider',
	function(
		zpzMdCalendarSvcProvider
	) {
		/** leave empty to use the default html templates **/
	}
]);