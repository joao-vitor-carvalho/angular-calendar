# zpzMdCalendar
zpzMdCalendar is a calendar module designed for use with 
Angular Material which allows for date selection and event 
previewing.

# run 


cd  zpzMdCalendar/demo/production/index.html run index.html 